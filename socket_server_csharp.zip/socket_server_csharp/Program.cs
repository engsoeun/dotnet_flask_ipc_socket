﻿using System.Net;
using System.Net.Sockets;
using System.Text;
using Newtonsoft.Json;

class Program
{
    static void Main()
    {
        Dictionary<string, (string, int)> ipDict = new Dictionary<string, (string, int)>();
        ipDict.Add("server", ("127.0.0.1", 3000));

        TcpListener server = null;

        try
        {
            server = new TcpListener(IPAddress.Parse(ipDict["server"].Item1), ipDict["server"].Item2);
            server.Start();

            Console.WriteLine("Server started");

            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                Console.WriteLine("Connected");

                SocketResponse(client);

                client.Close();
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"Exception: {e.Message}");
        }
        finally
        {
            server.Stop();
        }

        Console.WriteLine("\nServer stopped");
        Console.ReadKey();
    }

    static void SocketResponse(TcpClient client)
    {
        try
        {
            byte[] bytes = new byte[256];
            string data = null;

            NetworkStream stream = client.GetStream();
            int i;

            while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
            {
                data = Encoding.UTF8.GetString(bytes, 0, i);

                try
                {
                    RequestDTO requestData = JsonConvert.DeserializeObject<RequestDTO>(data);

                    ResponseDTO responseData = ProcessRequest(requestData);

                    string jsonResponse = JsonConvert.SerializeObject(responseData);

                    byte[] responseBytes = Encoding.UTF8.GetBytes(jsonResponse);
                    stream.Write(responseBytes, 0, responseBytes.Length);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to deserialize JSON: {ex.Message}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error processing client request: {ex.Message}");
        }
    }

    static ResponseDTO ProcessRequest(RequestDTO requestData)
    {
        List<int> numList = new List<int>();
        for (int i = requestData.StartNum; i <= requestData.EndNum; i++)
        {
            numList.Add(i);
        }

        return new ResponseDTO
        {
            Result = "S",
            Response = $"Result: {string.Join(", ", numList)}"
        };
    }
}

public class RequestDTO
{
    public int StartNum { get; set; }
    public int EndNum { get; set; }
}

public class ResponseDTO
{
    public string Result { get; set; }
    public object Response { get; set; }
}
